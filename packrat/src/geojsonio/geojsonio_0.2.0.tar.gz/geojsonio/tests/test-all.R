library("testthat")
library("geojsonio")
test_check("geojsonio")
